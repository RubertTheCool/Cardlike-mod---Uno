--@canvas x=0 y=0
-- ===== UNO =====
local MOD = cardlike.currentMod()
local UNO = MOD .. ':uno'

--@canvas x=0 y=192
-- Sprite sheet: 13 cards, each 39 x 55 (sheet is 507 x 55)
cardlike.addSpriteSheet {
  id = 'uno_cards',
  file = 'images/icon.png',
  frameWidth = 39,
  frameHeight = 55,
}

--@canvas x=16 y=480
local frames = {}
local ranks = { '2', '3', '4', '5', '6', '7', '8', '9', '10', 'Jack', 'Queen', 'King', 'Ace' }
for i, rank in ipairs(ranks) do
  frames[rank] = { sheet = 'uno_cards', x = i - 1, y = 0 }
end

--@canvas x=0 y=1232
cardlike.addSuit {
  id = 'uno',
  name = 'Uno',
  color = 'e5383b',
  frames = frames,
  inDeck = false,
}

--@canvas x=0 y=1536
-- Every scored Uno card: +floor(rank / 2) Mult. Ace (Wild): then X2 Mult
cardlike.on('onScore', function(state, step, result)
  local card = step.card
  if card:getSuit() ~= UNO then return end
  local rank = card:getRank()
  result:add(plusMult(math.floor(rank / 2)))
  if rank == 14 then result:add(xMult(2)) end
end)

--@canvas x=0 y=2176
-- Queen (Reverse): always scores again. Jack (Skip): 1 in 2 to score again
cardlike.on('repeatCard', function(state, step)
  local card = step.card
  if card:getSuit() ~= UNO then return end
  local rank = card:getRank()
  if rank == 12 then return 1 end
  if rank == 11 and state:chance(0.5) then return 1 end
end)

--@canvas x=0 y=3040
-- King (Draw 2): +1 hand size until the end of the round
cardlike.on('beforeAllCardsScored', function(state, step)
  for _, card in ipairs(step.hand.allCards) do
    if card:getSuit() == UNO and card:getRank() == 13 then
      state.extraEphemeralHandSize = state.extraEphemeralHandSize + 1
      card:popup('Draw 2!', colors.GREEN)
    end
  end
end)

--@canvas x=0 y=3840
-- ===== JOKERS =====
cardlike.addJoker {
  id = 'draw_25',
  image = 'images/draw_10.png',
  readableName = 'Draw 25',
  rarity = 'Rare',
  description = 'If your [b]final hand[/b] contains an [b]Uno[/b] card, change the suit of a random card in your deck to [b]Uno[/b]',
  triggers = {
    beforeAllCardsScored = function(joker, state, step, result)
      if state.handsLeft > 0 then return end   -- only the last hand of the round

      local hasUno = false
      for _, c in ipairs(step.hand.allCards) do
        if c:getSuit() == UNO then
          hasUno = true
          break
        end
      end
      if not hasUno then return end

      local pool = {}
      for _, c in ipairs(state.allCards) do
        if c:getSuit() ~= UNO then pool[#pool + 1] = c end
      end
      if #pool == 0 then return end

      local pick = pool[state:random(1, #pool)]
      pick:setSuit(UNO)
      pick:popup('Uno!', colors.MULT)
      result:say('Draw 25!', colors.MULT)
    end,
  },
}

--@canvas x=0 y=5568
cardlike.addJoker {
  id = 'zero',
  readableName = '0',
  rarity = 'Rare',
  description = 'If a [b]Uno[/b] card is in scoring hand, all non-[b]Uno[/b] cards score again',
  triggers = {
    repeatCard = function(joker, state, step, result)
      if step.card:getSuit() == UNO then return end
      for _, c in ipairs(step.hand.playedCards) do
        if c:getSuit() == UNO then return 1 end
      end
    end,
  },
}

--@canvas x=-160 y=6032
-- ===== BRAND (Game card) =====
cardlike.addConsumable {
  id = 'uno_card',
  type = 'game',
  readableName = 'Brand',
  price = 4,
  description = 'Change the suit of [b]1[/b] selected card to [b]Uno[/b]',
  canUse = function(ctx)
    if #ctx.selectedCards ~= 1 then return 'Select 1 card' end
    if ctx.selectedCards[1]:getSuit() == UNO then return 'Already Uno' end
    return ''
  end,
  action = function(ctx)
    local card = ctx.selectedCards[1]
    card:setSuit(UNO)
    card:punch()
  end,
}

--@canvas x=0 y=7680
-- ===== PACKS =====
local UNO_JOKERS = { 'draw_25', 'zero' }

--@canvas x=0 y=7920
local function ownsJoker(state, id)
  return state:hasJoker(MOD .. ':' .. id) or state:hasJoker(id)
end

--@canvas x=0 y=8432
-- Each slot has a small chance to be a joker you don't own yet
local function unoPackCards(state, count, jokerChance)
  local cards = {}
  local used = {}
  for i = 1, count do
    local spec = nil
    if state:chance(jokerChance) then
      local pool = {}
      for _, id in ipairs(UNO_JOKERS) do
        if not used[id] and not ownsJoker(state, id) then
          pool[#pool + 1] = id
        end
      end
      if #pool > 0 then
        local id = pool[state:random(1, #pool)]
        used[id] = true
        spec = { joker = id }
      end
    end
    cards[i] = spec or { playingCard = { suit = UNO, rank = state:random(2, 14) } }
  end
  return cards
end

--@canvas x=0 y=10080
cardlike.addPack {
  id = 'uno_pack',
  readableName = 'Uno Pack',
  price = 6,
  cardsShown = 2,
  shopWeight = 3,
  kind = 'deck',
  description = 'Choose from [b]2[/b] Uno cards. Rarely holds a joker',
  getCards = function(state, count, pack)
    return unoPackCards(state, count, 0.02)
  end,
}

--@canvas x=0 y=10720
cardlike.addPack {
  id = 'uno_pack_xl',
  readableName = 'Uno Pack XL',
  price = 9,
  cardsShown = 4,
  shopWeight = 2,
  kind = 'deck',
  description = 'Choose from [b]4[/b] Uno cards. Rarely holds a joker',
  getCards = function(state, count, pack)
    return unoPackCards(state, count, 0.04)
  end,
}

--@canvas x=0 y=11360
-- ===== DECK: UNO! Pack =====
local deckCards = {}
for _, suit in ipairs({ 'Spades', 'Hearts', 'Diamonds', 'Clubs' }) do
  for rank = 2, 10 do
    deckCards[#deckCards + 1] = { rank = rank, suit = suit }
  end
end
for rank = 11, 14 do   -- Jack, Queen, King, Ace: one each, Uno suit
  deckCards[#deckCards + 1] = { rank = rank, suit = UNO }
end

--@canvas x=16 y=12384
cardlike.addDeck {
  id = 'uno_pack_deck',
  name = 'UNO! Deck',
  description = 'All Face & Ace cards are replaced by [b][color="#ff007f"]Uno[/color][/b] cards. 15% chance for Shop Packs to be replaced by an [b][color="#ff007f"]Uno Pack[/color][/b].',
  cards = deckCards,
}

--@canvas x=0 y=12784
-- Deck perk: 15% chance per shop that one shop pack becomes an Uno Pack
local replacePending = false

--@canvas x=0 y=12960
local function onUnoPackDeck(state)
  return tostring(state.deck):find('uno_pack_deck', 1, true) ~= nil
end

--@canvas x=0 y=13392
cardlike.on('onShopEnter', function(state, step, result)
  replacePending = onUnoPackDeck(state) and state:chance(0.15)
end)

--@canvas x=0 y=13840
cardlike.on('onShopExit', function(state, step, result)
  replacePending = false
end)

--@canvas x=0 y=14192
-- The shop fills after onShopEnter, so the swap waits until the packs are on screen
cardlike.onFrame(function(frame)
  if not replacePending or not frame.inRun then return end
  local state = cardlike.state
  if state.phase ~= 'shop' then return end

  local packs = {}
  for _, c in ipairs(cardlike.cards('shop')) do
    local id = tostring(c.lastInfo.consumable)
    if c:getKind() == 'pack' and not id:find('uno_pack', 1, true) then
      packs[#packs + 1] = c
    end
  end
  if #packs == 0 then return end

  replacePending = false
  local pick = packs[state:random(1, #packs)]
  pick:setConsumableDef(MOD .. ':uno_pack')
end)
